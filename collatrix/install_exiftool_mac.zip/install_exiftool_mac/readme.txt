## install exiftool for mac
## Clara Bird, clara.birdferrer@gmail.com

This little script will install exiftool version 12.76 onto your machine. 

It's a shell script that contains the code listed here: https://exiftool.org/install.html, under MacOS/Full Perl Distribution

To run, just double click on the .sh file, a terminal window will open and start installing exiftool

At somepoint, terminal will ask you to enter your password. Enter your password and hit enter.

When its done running, it will prompt you to hit Enter. Once done you can close the window.

Exiftool is now installed on your machine.